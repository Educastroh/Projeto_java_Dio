package ContaBanco;
import java.util.Scanner;
public class ContaTerminal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Insira a agencia da conta: ");
        String agencia = scanner.nextLine();

        System.out.println("Por favor insira o numero da conta: ");
        int conta = scanner.nextInt();
        
        // Consumindo a quebra de linha
        scanner.nextLine();

        System.out.println("Insira seu nome: ");
        String nome = scanner.nextLine();

        System.out.println("Saldo: ");
        double saldo = scanner.nextDouble();

        System.out.println("Olá " + nome + ", obrigado por criar conta em nosso banco. Sua agencia é " + agencia + ", conta " + conta + " e seu saldo " + saldo + " já está disponível para saque.");
        
        scanner.close();
    }
}
